#include <main.cpp>
#include "CS210_Project_Three_Input_File.txt"

import re
import string

def string groceryList():
#reads the file to create a list
   itemList = open("CS210_Project_tTree_Input_File.txt", "r")
   print lines
   print len(lines)
   itemList.close()
   return itemList;

def printsomething():

    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v



    
