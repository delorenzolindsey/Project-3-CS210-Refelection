#include <iostream>
#include <string>

#include "CS210_Starter_PY_Code (1).py"
#include "CS210_Starter_CPP_Code.cpp"


using namespace std;

void countItemsFromList(groceryList()) {
	// get each item
	string GetItem() {
		return i;
	}
	void SetItem(string i) {

		this->i = i;
	}

}

void repeatNumberItem() {
	//get repeat number of each item
	const string->item = groceryItem();

	for (int i = 0; i < item; i++) {
		if (seen[i] == 0) {
			int count = 0;
			for (int j = i; j < item; j++)
				if (A[j] == A[i]) {
					count += 1;
					seen[j] = 1;
				}
		}
	}
	cout << item << " " << count << endl;

}

void histgramItem() {
	// get each item with histgram

	cout << item << endl;
	for (i = 0; i < repeatItem; i++) {
		for (j = 0; j < (i + 1); j++) {
			cout << "*";
		}
		cout << endl;
	}
}


int main() {

	int choice;
	bool menuOn = true;
	while (menuOn != false) {
		cout << "Thank you for choosing Corner Grocer. Please select a menu menu option. \n Please just type 1, 2, 3, or 4" << endl;
		cout << "1.List all items" << endl;
		cout << "2.List items and the number of times it was purchased" << endl;
		cout << "3.List items with a histogram" << endl;
		cout << "4.Exit program." << endl;

		cin >> choice;

		switch (choice) {
		case 1:
			//list all items
			cout << groceryList() << endl;
			break;
		case 2:
			//list items with numbers
			cout << "replace with item and number" << endl;
			break;
		case 3:
			//list histogram
			cout << "replace with histogram" << endl;
			break;
		case 4:
			cout << "Thank you. Come again." << endl;
			menuOn = false;
			break;
		default:
			cout << "Not a valid choice. Please pick a number 1, 2, 3, or 4." << endl;
			cin >> choice;
		}
	}
	return 0;
}